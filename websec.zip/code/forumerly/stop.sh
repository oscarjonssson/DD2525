docker stop lbs-services
